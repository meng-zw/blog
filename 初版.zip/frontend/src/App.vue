<template>
  <div>
    <h1>欢迎来到博客网站</h1>
    <p>这是一个使用 Vue 3 + TypeScript + Vite 构建的博客网站</p>
  </div>
</template>

<script setup lang="ts">
// App.vue 组件逻辑
</script>

<style scoped>
/* 组件样式 */
</style>
