package com.blog.controller;

import com.blog.entity.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * 标签控制器，处理文章标签相关请求
 */
@RestController
@RequestMapping("/tags")
@RequiredArgsConstructor
public class TagController {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取所有文章标签
     * @return 标签列表
     */
    @GetMapping
    public List<Tag> getAllTags() {
        TypedQuery<Tag> query = entityManager.createQuery(
                "SELECT t FROM Tag t ORDER BY t.name ASC", Tag.class);
        return query.getResultList();
    }
}
