package com.blog.controller;

import com.blog.entity.Category;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * 分类控制器，处理文章分类相关请求
 */
@RestController
@RequestMapping("/categories")
@RequiredArgsConstructor
public class CategoryController {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取所有文章分类
     * @return 分类列表
     */
    @GetMapping
    public List<Category> getAllCategories() {
        TypedQuery<Category> query = entityManager.createQuery(
                "SELECT c FROM Category c WHERE c.type = 'article' ORDER BY c.createdAt DESC", Category.class);
        return query.getResultList();
    }
}
