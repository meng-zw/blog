package com.blog.controller;

import com.blog.dto.AuthResponseDTO;
import com.blog.dto.LoginDTO;
import com.blog.dto.RegisterDTO;
import com.blog.entity.User;
import com.blog.utils.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 认证控制器，处理登录和注册请求
 */
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 用户登录
     * @param loginDTO 登录请求数据
     * @return 认证响应，包含token和用户信息
     */
    @PostMapping("/login")
    public AuthResponseDTO login(@RequestBody LoginDTO loginDTO) {
        // 进行身份认证
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginDTO.getUsername(), loginDTO.getPassword())
        );
        
        // 将认证信息保存到上下文
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        // 获取当前用户信息
        User user = (User) authentication.getPrincipal();
        
        // 生成JWT token
        String token = jwtUtils.generateToken(user.getUsername());
        
        // 构建响应
        AuthResponseDTO response = new AuthResponseDTO();
        response.setToken(token);
        response.setUserId(user.getId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        
        return response;
    }

    /**
     * 用户注册
     * @param registerDTO 注册请求数据
     * @return 认证响应，包含token和用户信息
     */
    @PostMapping("/register")
    @Transactional
    public AuthResponseDTO register(@RequestBody RegisterDTO registerDTO) {
        // 创建新用户
        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setEmail(registerDTO.getEmail());
        user.setPhone(registerDTO.getPhone());
        user.setRole("ROLE_USER");
        
        // 保存用户到数据库
        entityManager.persist(user);
        entityManager.flush();
        
        // 直接生成JWT token，跳过立即认证步骤
        String token = jwtUtils.generateToken(user.getUsername());
        
        // 构建响应
        AuthResponseDTO response = new AuthResponseDTO();
        response.setToken(token);
        response.setUserId(user.getId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        
        return response;
    }
}
