package com.blog.controller;

import com.blog.entity.Category;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * 工具分类控制器，处理工具分类相关请求
 */
@RestController
@RequestMapping("/tool-categories")
@RequiredArgsConstructor
public class ToolCategoryController {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取所有工具分类
     * @return 工具分类列表
     */
    @GetMapping
    public List<Category> getAllToolCategories() {
        TypedQuery<Category> query = entityManager.createQuery(
                "SELECT c FROM Category c WHERE c.type = 'tool' ORDER BY c.createdAt DESC", Category.class);
        return query.getResultList();
    }
}
