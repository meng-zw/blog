package com.blog.controller;

import com.blog.dto.CommentDTO;
import com.blog.dto.ToolDTO;
import com.blog.entity.Category;
import com.blog.entity.Comment;
import com.blog.entity.Tool;
import com.blog.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

/**
 * 工具控制器，处理工具相关请求
 */
@RestController
@RequestMapping("/tools")
@RequiredArgsConstructor
public class ToolController {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取工具列表
     * @return 工具列表
     */
    @GetMapping
    public List<Tool> getAllTools() {
        TypedQuery<Tool> query = entityManager.createQuery(
                "SELECT t FROM Tool t ORDER BY t.createdAt DESC", Tool.class);
        return query.getResultList();
    }

    /**
     * 获取热门工具
     * @return 热门工具列表
     */
    @GetMapping("/popular")
    public List<Tool> getPopularTools() {
        TypedQuery<Tool> query = entityManager.createQuery(
                "SELECT t FROM Tool t ORDER BY t.viewCount DESC", Tool.class);
        query.setMaxResults(10);
        return query.getResultList();
    }

    /**
     * 获取工具详情
     * @param id 工具ID
     * @return 工具详情
     */
    @GetMapping("/{id}")
    public Tool getToolById(@PathVariable Long id) {
        Tool tool = entityManager.find(Tool.class, id);
        if (tool != null) {
            // 增加浏览量
            tool.setViewCount(tool.getViewCount() + 1);
            entityManager.merge(tool);
        }
        return tool;
    }

    /**
     * 获取工具评论
     * @param id 工具ID
     * @return 评论列表
     */
    @GetMapping("/{id}/comments")
    public List<Comment> getToolComments(@PathVariable Long id) {
        TypedQuery<Comment> query = entityManager.createQuery(
                "SELECT c FROM Comment c WHERE c.toolId = :toolId AND c.parentId IS NULL ORDER BY c.createdAt DESC", Comment.class);
        query.setParameter("toolId", id);
        return query.getResultList();
    }

    /**
     * 分享工具
     * @param toolDTO 工具请求数据
     * @return 分享的工具
     */
    @PostMapping
    @Transactional
    public Tool shareTool(@RequestBody ToolDTO toolDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();

        // 获取分类对象
        Category category = entityManager.find(Category.class, toolDTO.getCategoryId());
        if (category == null) {
            throw new RuntimeException("分类不存在");
        }

        Tool tool = new Tool();
        tool.setName(toolDTO.getName());
        tool.setDescription(toolDTO.getDescription());
        tool.setUrl(toolDTO.getUrl());
        tool.setCategory(category);
        tool.setUser(currentUser);
        tool.setViewCount(0L);
        tool.setCommentCount(0L);

        entityManager.persist(tool);
        entityManager.flush();

        return tool;
    }

    /**
     * 提交工具评论
     * @param id 工具ID
     * @param commentDTO 评论请求数据
     * @return 提交的评论
     */
    @PostMapping("/{id}/comments")
    @Transactional
    public Comment addToolComment(@PathVariable Long id, @RequestBody CommentDTO commentDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();

        Comment comment = new Comment();
        comment.setContent(commentDTO.getContent());
        comment.setUser(currentUser);
        comment.setTargetId(id);
        comment.setTargetType("tool");
        
        // 设置父评论
        if (commentDTO.getParentId() != null) {
            Comment parentComment = entityManager.find(Comment.class, commentDTO.getParentId());
            if (parentComment != null) {
                comment.setParent(parentComment);
            }
        }

        entityManager.persist(comment);
        entityManager.flush();

        // 更新工具评论数
        Tool tool = entityManager.find(Tool.class, id);
        if (tool != null) {
            tool.setCommentCount(tool.getCommentCount() + 1);
            entityManager.merge(tool);
        }

        return comment;
    }
}
