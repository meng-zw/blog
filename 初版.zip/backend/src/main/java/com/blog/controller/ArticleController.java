package com.blog.controller;

import com.blog.dto.ArticleDTO;
import com.blog.dto.CommentDTO;
import com.blog.entity.Article;
import com.blog.entity.Category;
import com.blog.entity.Comment;
import com.blog.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Date;

/**
 * 文章控制器，处理文章相关请求
 */
@RestController
@RequestMapping("/articles")
@RequiredArgsConstructor
public class ArticleController {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取最新文章列表
     * @return 最新文章列表
     */
    @GetMapping("/latest")
    public List<Article> getLatestArticles() {
        TypedQuery<Article> query = entityManager.createQuery(
                "SELECT a FROM Article a ORDER BY a.createdAt DESC", Article.class);
        query.setMaxResults(10);
        return query.getResultList();
    }

    /**
     * 获取文章详情
     * @param id 文章ID
     * @return 文章详情
     */
    @GetMapping("/{id}")
    public Article getArticleById(@PathVariable Long id) {
        Article article = entityManager.find(Article.class, id);
        if (article != null) {
            // 增加浏览量
            article.setViewCount(article.getViewCount() + 1);
            entityManager.merge(article);
        }
        return article;
    }

    /**
     * 获取文章评论
     * @param id 文章ID
     * @return 评论列表
     */
    @GetMapping("/{id}/comments")
    public List<Comment> getArticleComments(@PathVariable Long id) {
        TypedQuery<Comment> query = entityManager.createQuery(
                "SELECT c FROM Comment c WHERE c.articleId = :articleId AND c.parentId IS NULL ORDER BY c.createdAt DESC", Comment.class);
        query.setParameter("articleId", id);
        return query.getResultList();
    }

    /**
     * 发布文章
     * @param articleDTO 文章请求数据
     * @return 发布的文章
     */
    @PostMapping
    @Transactional
    public Article publishArticle(@RequestBody ArticleDTO articleDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();

        // 获取分类对象
        Category category = entityManager.find(Category.class, articleDTO.getCategoryId());
        if (category == null) {
            throw new RuntimeException("分类不存在");
        }

        Article article = new Article();
        article.setTitle(articleDTO.getTitle());
        article.setContent(articleDTO.getContent());
        article.setUser(currentUser);
        article.setCategory(category);
        article.setViewCount(0L);
        article.setCommentCount(0L);
        // 生成HTML内容（这里简化处理，实际应该使用Markdown解析库）
        article.setHtmlContent(articleDTO.getContent());

        entityManager.persist(article);
        entityManager.flush();

        return article;
    }

    /**
     * 保存草稿
     * @param articleDTO 文章请求数据
     * @return 保存的草稿
     */
    @PostMapping("/draft")
    @Transactional
    public Article saveDraft(@RequestBody ArticleDTO articleDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();

        // 获取分类对象
        Category category = entityManager.find(Category.class, articleDTO.getCategoryId());
        if (category == null) {
            throw new RuntimeException("分类不存在");
        }

        Article article = new Article();
        article.setTitle(articleDTO.getTitle());
        article.setContent(articleDTO.getContent());
        article.setUser(currentUser);
        article.setCategory(category);
        article.setViewCount(0L);
        article.setCommentCount(0L);
        // 生成HTML内容（这里简化处理，实际应该使用Markdown解析库）
        article.setHtmlContent(articleDTO.getContent());

        entityManager.persist(article);
        entityManager.flush();

        return article;
    }

    /**
     * 提交文章评论
     * @param id 文章ID
     * @param commentDTO 评论请求数据
     * @return 提交的评论
     */
    @PostMapping("/{id}/comments")
    @Transactional
    public Comment addComment(@PathVariable Long id, @RequestBody CommentDTO commentDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();

        Comment comment = new Comment();
        comment.setContent(commentDTO.getContent());
        comment.setUser(currentUser);
        comment.setTargetId(id);
        comment.setTargetType("article");
        
        // 设置父评论
        if (commentDTO.getParentId() != null) {
            Comment parentComment = entityManager.find(Comment.class, commentDTO.getParentId());
            if (parentComment != null) {
                comment.setParent(parentComment);
            }
        }

        entityManager.persist(comment);
        entityManager.flush();

        // 更新文章评论数
        Article article = entityManager.find(Article.class, id);
        if (article != null) {
            article.setCommentCount(article.getCommentCount() + 1);
            entityManager.merge(article);
        }

        return comment;
    }
}
