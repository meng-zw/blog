package com.blog.dto;

import lombok.Data;

/**
 * 认证响应DTO
 */
@Data
public class AuthResponseDTO {
    private String token;
    private Long userId;
    private String username;
    private String email;
}
