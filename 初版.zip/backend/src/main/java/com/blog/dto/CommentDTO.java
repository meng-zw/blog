package com.blog.dto;

import lombok.Data;

/**
 * 评论请求DTO
 */
@Data
public class CommentDTO {
    private String content;
    private Long parentId;
}
