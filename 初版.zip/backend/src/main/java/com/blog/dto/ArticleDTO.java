package com.blog.dto;

import lombok.Data;

import java.util.List;

/**
 * 文章请求DTO
 */
@Data
public class ArticleDTO {
    private String title;
    private Long categoryId;
    private List<Long> tags;
    private String content;
    private Integer status;
}
