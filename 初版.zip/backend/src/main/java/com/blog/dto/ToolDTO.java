package com.blog.dto;

import lombok.Data;

/**
 * 工具请求DTO
 */
@Data
public class ToolDTO {
    private String name;
    private String description;
    private String url;
    private Long categoryId;
}
