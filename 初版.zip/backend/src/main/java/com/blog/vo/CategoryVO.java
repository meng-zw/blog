package com.blog.vo;

import lombok.Data;

/**
 * 分类视图对象
 */
@Data
public class CategoryVO {

    private Long id;
    private String name;
    private String type;
    private Long parentId;
}
